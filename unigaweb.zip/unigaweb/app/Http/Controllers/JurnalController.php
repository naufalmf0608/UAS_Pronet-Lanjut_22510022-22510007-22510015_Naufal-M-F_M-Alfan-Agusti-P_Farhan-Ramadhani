<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jurnal;
use Illuminate\Support\Facades\Storage;


class JurnalController extends Controller
{
    public function create()
    {
        return view('crudjurnal');
    }

    public function store(Request $request)
{
    $request->validate([
        'nama' => 'required',
        'nim' => 'required',
        'email' => 'required|email',
        'file' => 'required|mimes:pdf|max:10000',
    ]);

    $filePath = $request->file('file')->store('jurnals', 'public');

    $jurnal = new Jurnal();
    $jurnal->nama = $request->input('nama');
    $jurnal->nim = $request->input('nim');
    $jurnal->email = $request->input('email');
    $jurnal->filename = $request->file('file')->getClientOriginalName();
    $jurnal->file_path = $filePath;
    $jurnal->save();

    return redirect()->route('jurnals.index')->with('success', 'Jurnal berhasil diunggah');
}
    public function index()
    {
        $jurnals = Jurnal::all();
        return view('jurnal.index', compact('jurnals'));
    }

    public function show($id)
    {
        $jurnal = Jurnal::findOrFail($id);
        return view('jurnal.show', compact('jurnal'));
    }

    public function download($id)
{
    $jurnal = Jurnal::findOrFail($id);
    $filePath = storage_path('app/public/' . $jurnal->file_path);

    if (!file_exists($filePath)) {
        abort(404, 'File not found');
    }
    return response()->download($filePath, $jurnal->filename);
}

public function search(Request $request)
    {
        $keyword = $request->input('keyword');
        $jurnals = Jurnal::where('nama', 'LIKE', "%$keyword%")
            ->orWhere('nim', 'LIKE', "%$keyword%")
            ->orWhere('email', 'LIKE', "%$keyword%")
            ->orWhere('filename', 'LIKE', "%$keyword%")
            ->get();

        return view('jurnal.baca', compact('jurnals'));
    }

}