<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" href="imagef/logo1.png"
    type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   {{-- <link rel="stylesheet" href="{{ asset('css/style.css') }}"> --}}
   @include('include.style')
   @include('include.beritas')
   @include('include.nav')

</head>
<body>


    <!-- Jumbotron -->
    <div class="jumbotron" style="background-image: url('{{ asset('imagef/1.jpg') }}');">
    </div>

    <hr>

    {{-- isi --}}
    <div class="berita">
        <img src="{{ asset('imagef/b3p1.jpg') }}" alt="">
        <h1>UPACARA PERINGATAN HARI KEBANGKITAN NASIONAL BERSAMAAN DENGAN DIES NATALIS KE-44 UNIGA</h1>



        <p>SIARINDOMEDIA.COM – Bertepatan dengan Hari Kebangkitan Nasional pada 20 Mei, Universitas Gajayana (Uniga) Malang menggelar upacara
            sekaligus tasyakuran untuk memperingati Dies Natalis ke-44 yang diikuti segenap civitas akademika. Acara tersebut dilangsungkan di lapangan parkir timur kampus Uniga.

            Dies Natalis kali menjadi simbol refleksi atas perjalanan panjang Uniga dalam mendidik generasi bangsa (20/5).

            Dalam sambutannya, Prof. Dr. Ernani Hadiyati, S.E., M.S. menyampaikan civitas akademika Uniga telah meraih berbagai kemajuan dalam melaksanakan Tridarma perguruan tinggi.

            Sesuai dengan Milestone Uniga saat ini, Uniga telah mencapai proses yang optimal untuk menghasilkan lulusan yang mampu mengimplementasikan ilmunya dalam masyarakat di mana mereka berada.

            “Pada tonggak ini, Uniga terus berinovasi untuk menyelenggarakan Tridarma perguruan tinggi secara optimal,” ungkap Prof Ernani.

            “Kami berkomitmen mengembangkan model pembelajaran inovatif berbasis riset dan meningkatkan produktivitas karya ilmiah dan hak cipta. Langkah ini diambil agar Uniga dapat berkontribusi lebih signifikan dalam pembangunan bangsa,” tambahnya.</p>


        <p>Sampai usia ke-44 ini, Uniga telah mengelola 13 program studi yang terdiri dari 1 program studi S3, yaitu Program Doktor Ilmu Manajemen, 2 program magister, yaitu Magister Akuntansi dan Magister Manajemen, serta 10 program sarjana (S1).</p>

        <img src="{{ asset('imagef/b3p2.jpg') }}" alt="">

        <p>Program-program studi tersebut berada di bawah naungan tiga fakultas dan pasca sarjana. Semua program studi telah terakreditasi, dengan satu program studi yang telah meraih akreditasi unggul, yaitu Program Studi S1 Akuntansi.</p>

        <p>Serangkaian langkah strategis yang dilakukan Uniga dalam meningkatkan mutu pendidikan telah mencakup
            kerja sama dengan beberapa universitas luar negeri. Salah satunya adalah Universiti Teknologi Malaysia (UTM).
            Kerja sama ini bertujuan untuk memperluas wawasan akademik, meningkatkan kualitas penelitian, dan menyediakan lebih banyak kesempatan bagi mahasiswa dan dosen untuk berpartisipasi dalam program pertukaran dan kolaborasi internasional.</p>



        <p>“Agar Uniga sebagai institusi perguruan tinggi tidak hanya sekadar eksis, tetapi juga mampu berkembang dan mengakselerasi diri secara internal maupun eksternal dengan kerja sama antara civitas akademika dan dukungan penuh dari yayasan,” tandasnya.
            sumber : https://siarindomedia.com/2024/05/20/upacara-peringatan-hari-kebangkitan-nasional-bersamaan-dengan-dies-natalis-ke-44-uniga/#google_vignette</p>

    </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                <p>Email:</p>
                <iframe class="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                        width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                        allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="col-md-4">
                <h5>Informasi Tentang</h5>
                    <ul>
                        <li><a href="#">Portal Akademik</a></li>
                        <li><a href="#">Jadwal Kuliah</a></li>
                        <li><a href="#">Kuliah Online</a></li>
                        <li><a href="#">Journal @UNIGA</a></li>
                        <li><a href="#">Conference @UNIGA</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Link Lainnya</h5>
                    <ul>
                        <li><a href="#">Jurnal Pengabdian</a></li>
                        <li><a href="#">Blog UNIGA</a></li>
                        <li><a href="#">Perpustakaan</a></li>
                    </ul>
            </div>
        </div>
    </div>
</footer>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.forEach(function (link) {
                    link.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    });
</script>
</body>
</html>
