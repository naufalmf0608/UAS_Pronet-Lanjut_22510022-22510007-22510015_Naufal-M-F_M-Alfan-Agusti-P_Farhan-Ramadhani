<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Detail Jurnal</h2>
        <h3>{{ $jurnal->nama }}</h3>
        <p><strong>Penulis:</strong> {{ $jurnal->nama }}</p>
        <p><strong>NIM:</strong> {{ $jurnal->nim }}</p>
        <p><strong>Email:</strong> {{ $jurnal->email }}</p>
        <p><strong>Filename:</strong> {{ $jurnal->filename }}</p>
        <embed src="{{ asset('storage/' . $jurnal->file_path) }}" type="application/pdf" width="100%" height="600px" />
        <br><br>
        <a href="{{ route('jurnals.download', $jurnal->id) }}" class="btn btn-primary">Download Jurnal</a>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
