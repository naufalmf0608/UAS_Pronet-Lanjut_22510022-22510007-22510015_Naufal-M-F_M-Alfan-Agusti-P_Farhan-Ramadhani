<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baca Jurnal</title>
    <link rel="icon" href="{{ asset('imagef/logo1.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('css/crudjurnal.css') }}">
</head>
<body>
    <!-- Navbar -->
    <a href="{{ route('index') }}" class="btn btn-secondary mb-4">Kembali ke Index</a>

    <!-- Content Section -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-4">Arsip Jurnal</h2>
                <!-- Pencarian Jurnal -->
                <form action="{{ route('search-jurnal') }}" method="GET" class="mb-4">
                    <div class="form-group">
                        <input type="text" name="keyword" class="form-control" placeholder="Cari jurnal...">
                    </div>
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>

                <!-- Daftar Jurnal -->
                <ul class="list-group">
                    @if($jurnals->isEmpty())
                        <p>Belum ada jurnal yang ditambahkan.</p>
                    @else
                        @foreach($jurnals as $jurnal)
                            <li class="list-group-item">
                                <h5>{{ $jurnal->nama }}</h5>
                                <p>Penulis: {{ $jurnal->nama }}</p>
                                <p>NIM: {{ $jurnal->nim }}</p>
                                <p>Email: {{ $jurnal->email }}</p>
                                <p>Filename: {{ $jurnal->filename }}</p>
                                <a href="{{ route('jurnals.show', $jurnal->id) }}" class="btn btn-primary">Baca</a>
                                <a href="{{ route('jurnals.download', $jurnal->id) }}" class="btn btn-success">Download</a>
                            </li>
                        @endforeach
                    @endif
                </ul>
            </div>
        </div>
    </div>



    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
