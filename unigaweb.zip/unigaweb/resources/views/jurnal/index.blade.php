<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Jurnal</h2>
        <form action="{{ url('search-jurnal') }}" method="GET" class="mb-4">
            <div class="form-group">
                <input type="text" name="keyword" class="form-control" placeholder="Cari jurnal...">
            </div>
            <button type="submit" class="btn btn-primary">Cari</button>
        </form>
        <ul class="list-group">
            @if($jurnals->isEmpty())
                <p>Belum ada jurnal yang ditambahkan.</p>
            @else
                @foreach($jurnals as $jurnal)
                    <li class="list-group-item">
                        {{ $jurnal->nama }} - {{ $jurnal->filename }}
                        <a href="{{ route('jurnals.show', $jurnal->id) }}" class="btn btn-info btn-sm float-right ml-2">Buka</a>
                        <a href="{{ route('jurnals.download', $jurnal->id) }}" class="btn btn-primary btn-sm float-right">Download</a>
                    </li>
                @endforeach
            @endif
        </ul>
    </div>
</body>
</html>
