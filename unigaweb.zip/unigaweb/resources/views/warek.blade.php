<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Wakil Rektor</title>
    <link rel="icon" href="imagef/logo1.png"
    type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    @include('include.nav')
    {{-- <style>
        .navbar {
            background-color: #cc251c;
            z-index: 10;
        }

        .nav-item {
            position: relative;
        }

        .nav-link::before {
            content: "";
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: #ffffff;
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .nav-link:hover::before {
            transform: scaleX(1);
        }

        .nav-link {
            color: #ffffff;
            transition: color 0.3s ease;
        }

        .nav-link:hover {
            color: #ffffff;
        }

        .navbar-nav .nav-link {
            color: white !important;
            font-size: 1.2em;
        }

        .navbar-nav .nav-link.active {
            background-color: #555 !important;
            color: white !important;
        }

        .container-fluid1 {
            display: flex;
            border: 1px solid black;
            margin: 50px;
            padding: 50px;
        }

        .text-1 {
            align-items: center;
        }

        .container-fluid2 {
            background-color: #cc241c;
            color: white;
            padding: 20px;
            border-radius: 5px;
        }

        .rkt {
            width: 250px;
            height: auto;
        }

        .overlay {
            position: relative;
            left: 0;
            transform: translateY(10%);
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
        }

        .jumbotron {
            background-image: url("1.jpg");
            background-size: cover;
            background-position: center;
            height: 500px;
            color: white;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .menu2 {
            background-color: #cc241c;
            display: flex;
            padding-bottom: 2%;
        }

        .menu-item {
            flex-grow: 1;
            text-align: center;
            justify-content: center;
            position: relative;
        }

        .menu-text {
            color: rgb(255, 255, 255);
            padding: 20px;
        }

        .menu-item::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background-color: #ffffff;
            transition: width 0.3s ease;
        }

        .icon {
            height: 30px;
            margin-bottom: 5px;
        }

        .footer {
            background-color: #cc241c;
            color: #000;
            padding: 20px 0;
        }

        .footer a {
            color: #000;
        }

        .footer a:hover {
            text-decoration: none;
        }

        .footer .map {
            height: 250px;
            width: 350px;
        }

        .Bottom-logo {
            margin-bottom: 30px;
        }
    </style> --}}
</head>
<body>
    <!-- Navbar -->
    {{-- <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <a class="navbar-brand" href="#">
            <img src="{{ asset('imagef/logo.png') }}" alt="Logo" width="300" height="auto">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto" id="navbar-menu">
                <li class="nav-item active">
                    <a class="nav-link" href="{{ url('index') }}"><b>Home</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('lppm.html') }}"><b>Tentang LPPM</b></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="jurnalDropdown" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b>Jurnal</b></a>
                    <div class="dropdown-menu" aria-labelledby="jurnalDropdown">
                        <a class="dropdown-item" href="/baca">Baca Jurnal</a>
                        <a class="dropdown-item" href="{{ url('crudjurnal') }}">Input Jurnal</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"><b>Arsip</b></a>
                </li>
            </ul>
        </div>
    </nav> --}}


    <!-- Background with text, logo, etc. -->
    <div class="jumbotron" style="background-image: url('{{ asset('imagef/1.jpg') }}');">
    </div>

    <!-- 4 Menu -->
    <div class="menu2">
        <div class="menu-item">
            <div class="icon dashboard-icon"></div>
            <a href="{{ url('/prektor') }}" class="nav-link "><b>PROFIL REKTOR</b></a>
        </div>
        <div class="menu-item">
            <div class="icon cari-alumni-icon"></div>
            <a href="{{ url('/warek') }}" class="nav-link active"><b>PROFIL WAKIL REKTOR</b></a>
        </div>
    </div>

    <!-- White section with rector's welcome -->
    <div class="container-fluid1">
        <img class="rkt" src="{{ asset('imagef/warek1.jpg') }}" alt="2" />
        <div class="overlay">
            <h3>Profil Wakil Rektor Bidang Akademik dan Umum</h3>
            <p>
                Assalamu’alaikum wr.wb.<br />
                Kampus merupakan salah satu tempat untuk mengembangkan ilmu oleh mahasiswa, dosen dan peneliti. Hadirnya lembaga penelitian dan pengabdian kepada masyarakat (LPPM) ini menjadi suatu wadah dalam kegiatan penelitian dan pengabdian. Program penelitian dan pengabdian yang dihasilkan nantinya diharapkan mampu menjadi inovasi ilmu pengetahuan, teknologi dan seni (IPTEKS) yang berdaya guna di masyarakat. Kami berharap LPPM Universitas Gajayana Malang dapat berkontribusi di masyarakat melalui program penelitian dan pengabdian yang memanfaatkan potensi alam dan kearifan lokal di daerah Kota Malang. Selain itu, kami juga berterima kasih apabila segenap stakeholder, private partnership dan pemerintah Kota Malang mendukung program penelitian dan pengabdian di UNIGA Malang. Semoga Universitas Gajayana Malang terus maju dan menghasilkan inovasi-inovasi baru. Wassalamu’alaikum wr.wb.<br />
                <h6>Rektor Universitas Gajayana Malang Prof. Dr. Ernani Hadiyati, S.E., M.S.</h6>
            </p>
        </div>
    </div>

    <div class="container-fluid1">
        <div class="overlay">
            <h3>Profil Wakil Rektor Bidang Kemahasiswaan dan Kerjasama</h3>
            <p>
                Assalamu’alaikum wr.wb.<br />
                Kampus merupakan salah satu tempat untuk mengembangkan ilmu oleh mahasiswa, dosen dan peneliti. Hadirnya lembaga penelitian dan pengabdian kepada masyarakat (LPPM) ini menjadi suatu wadah dalam kegiatan penelitian dan pengabdian. Program penelitian dan pengabdian yang dihasilkan nantinya diharapkan mampu menjadi inovasi ilmu pengetahuan, teknologi dan seni (IPTEKS) yang berdaya guna di masyarakat. Kami berharap LPPM Universitas Gajayana Malang dapat berkontribusi di masyarakat melalui program penelitian dan pengabdian yang memanfaatkan potensi alam dan kearifan lokal di daerah Kota Malang. Selain itu, kami juga berterima kasih apabila segenap stakeholder, private partnership dan pemerintah Kota Malang mendukung program penelitian dan pengabdian di UNIGA Malang. Semoga Universitas Gajayana Malang terus maju dan menghasilkan inovasi-inovasi baru. Wassalamu’alaikum wr.wb.<br />
                <h6>Rektor Universitas Gajayana Malang Prof. Dr. Ernani Hadiyati, S.E., M.S.</h6>
            </p>
        </div>
        <img class="rkt" src="{{ asset('imagef/warek2.jpg') }}" alt="3" />
    </div>

    <hr>

    <div class="row">

        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card">
                <img src="imagef/b1.jpg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>Gelar Sosialisasi Rekognisi Pembelajaran Lampau, Uniga Siap Terapkan SIERRA</h4></div>
                    Bertempat di Aula Pascasarjana Gedung C Universitas Gajayana (Uniga) Malang, segenap Pimpinan Universitas, Dekan, Ketua Prodi, dan Calon Asessor mengikuti Sosialisasi Rekognisi Pembelajaran Lampau (RPL).
                </div>

                <div class="card-footer">
                    <a href="{{ url('berita1') }}" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 mb-3">
            <div class="card">
                <img src="imagef/b2.jpeg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>Dies Natalis ke-44 Universitas Gajayana Malang; Tingkatkan Inovasi Teknologi, Komitmen Lahirkan Lulusan Adaptif</h4></div>
                    Universitas Gajayana Malang (Uniga) telah mencapai usia ke-44 tahun. Dies Natalisnya dirayakan, Senin (20/5) kemarin. Di hadapan civitas akademika, Rektor Uniga Prof. Dr. Ernani Hadiyati, S.E., M.S bersuara dengan lantang.
                </div>

                <div class="card-footer">
                    <a href="{{ url('berita2') }}" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 mb-3">
            <div class="card">
                <img src="imagef/b3.jpg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>UPACARA PERINGATAN HARI KEBANGKITAN NASIONAL BERSAMAAN DENGAN DIES NATALIS KE-44 UNIGA</h4></div>
                    SIARINDOMEDIA.COM – Bertepatan dengan Hari Kebangkitan Nasional pada 20 Mei, Universitas Gajayana (Uniga) Malang menggelar upacara sekaligus tasyakura...
                </div>

                <div class="card-footer">
                    <a href="{{ url('berita3') }}" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                    <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                    <p>Email:</p>
                    <iframe class="map"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                            width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                            allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
                <div class="col-md-4">
                    <h5>Informasi Tentang</h5>
                    <ul>
                        <li><a href="#">Portal Akademik</a></li>
                        <li><a href="#">Jadwal Kuliah</a></li>
                        <li><a href="#">Kuliah Online</a></li>
                        <li><a href="#">Journal @UNIGA</a></li>
                        <li><a href="#">Conference @UNIGA</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Link Lainnya</h5>
                    <ul>
                        <li><a href="#">Jurnal Pengabdian</a></li>
                        <li><a href="#">Blog UNIGA</a></li>
                        <li><a href="#">Perpustakaan</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
