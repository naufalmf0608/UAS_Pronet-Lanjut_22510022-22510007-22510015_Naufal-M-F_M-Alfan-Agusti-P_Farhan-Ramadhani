<style>
.berita {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    max-width: 80%;
    margin: 20px auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.berita h1 {
    font-size: 2em;
    color: #2c3e50;
    margin-bottom: 20px;
}

.berita p {
    margin-bottom: 20px;
}

.berita img {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 20px 0;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    justify-content: center;
    align-items: center
}
</style>
