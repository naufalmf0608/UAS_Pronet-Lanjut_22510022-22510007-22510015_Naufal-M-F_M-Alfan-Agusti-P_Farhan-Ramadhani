<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <a class="navbar-brand" href="#">
        <img src="{{ asset('imagef/logo.png') }}" alt="Logo" width="300" height="auto">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto" id="navbar-menu">
            <li class="nav-item">
                <a class="nav-link active" href="{{ url('index') }}"><b>Home</b></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ url('lppm') }}"><b>Tentang LPPM</b></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="jurnalDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b>Jurnal</b></a>
                <div class="dropdown-menu" aria-labelledby="jurnalDropdown">
                    <a class="dropdown-item" href="/baca">Baca Jurnal</a>
                    <a class="dropdown-item" href="/crudjurnal">Input Jurnal</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ url('arsip') }}"><b>Arsip</b></a>
            </li>
        </ul>
    </div>
</nav>
