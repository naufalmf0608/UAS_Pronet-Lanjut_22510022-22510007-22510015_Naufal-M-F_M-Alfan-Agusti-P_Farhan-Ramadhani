<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\JurnalController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/index', function () {
    return view('index');
});

// Route untuk halaman lppm.html
Route::get('/lppm', function () {
    return view('lppm');
});

// Route untuk halaman rektor.html
Route::get('/prektor', function () {
    return view('prektor');
});

// Route untuk halaman warek.html
Route::get('/warek', function () {
    return view('warek');
});

Route::get('/crudjurnal', function () {
    return view('crudjurnal');
});

Route::get('/baca', function () {
    return view('baca');
});

Route::get('/berita1', function () {
    return view('berita1');
});

Route::get('/berita2', function () {
    return view('berita2');
});

Route::get('/berita3', function () {
    return view('berita3');
});

Route::get('/arsip', function () {
    return view('arsip');
});

Route::get('/baca', [JurnalController::class, 'index'])->name('baca.index');
Route::post('/store-jurnal', [JurnalController::class, 'store'])->name('store-jurnal');


Route::get('/jurnals', [JurnalController::class, 'index'])->name('jurnals.index');
Route::get('/jurnals/{id}', [JurnalController::class, 'show'])->name('jurnals.show');
Route::get('/jurnals/{id}/download', [JurnalController::class, 'download'])->name('jurnals.download');
Route::get('/search-jurnal', [JurnalController::class, 'search'])->name('search-jurnal');