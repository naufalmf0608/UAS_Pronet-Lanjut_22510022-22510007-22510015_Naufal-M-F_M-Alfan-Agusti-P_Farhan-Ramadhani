<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Jurnal</h2>
        <form action="<?php echo e(url('search-jurnal')); ?>" method="GET" class="mb-4">
            <div class="form-group">
                <input type="text" name="keyword" class="form-control" placeholder="Cari jurnal...">
            </div>
            <button type="submit" class="btn btn-primary">Cari</button>
        </form>
        <ul class="list-group">
            <?php if($jurnals->isEmpty()): ?>
                <p>Belum ada jurnal yang ditambahkan.</p>
            <?php else: ?>
                <?php $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <?php echo e($jurnal->nama); ?> - <?php echo e($jurnal->filename); ?>

                        <a href="<?php echo e(route('jurnals.show', $jurnal->id)); ?>" class="btn btn-info btn-sm float-right ml-2">Buka</a>
                        <a href="<?php echo e(route('jurnals.download', $jurnal->id)); ?>" class="btn btn-primary btn-sm float-right">Download</a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/jurnal/index.blade.php ENDPATH**/ ?>