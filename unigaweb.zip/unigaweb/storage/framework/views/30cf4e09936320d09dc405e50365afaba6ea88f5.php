<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arsip</title>
    <link rel="icon" href="imagef/logo1.png"
    type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   
   <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('include.beritas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('imagef/logo.png')); ?>" alt="Logo" width="300" height="auto">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto" id="navbar-menu">
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(url('index')); ?>"><b>Home</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('lppm')); ?>"><b>Tentang LPPM</b></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="jurnalDropdown" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b>Jurnal</b></a>
                    <div class="dropdown-menu" aria-labelledby="jurnalDropdown">
                        <a class="dropdown-item" href="/baca">Baca Jurnal</a>
                        <a class="dropdown-item" href="<?php echo e(url('crudjurnal')); ?>">Input Jurnal</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(url('arsip')); ?>"><b>Arsip</b></a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Jumbotron -->
    <div class="jumbotron" style="background-image: url('<?php echo e(asset('imagef/1.jpg')); ?>');">
    </div>

    <hr>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip1.jpg')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>YAYASAN PENDIDIKAN GAJAYANA PROF. DR. M.SALEH BERPULANG, INSAN PENDIDIKAN DI MALANG BERDUKA</b></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip2.jpg')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>HALAL BIHALAL CIVITAS AKADEMIKA UNIGA</b></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip3.png')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>Himkomunika Intip Operasional LPPL Agropolitan Televisi</b></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip4.jpg')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>ASESMEN LAPANGAN PRODI SISTEM INFORMASI BERSAMA TIM ASESOR LAM-INFOKOM</b></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip5.jpg')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>UNIVERSITAS GAJAYANA MALANG; TAMBAH GURU BESAR BIDANG ILMU AKUNTANSI</b></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('imagef/arsip6.jpg')); ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text"><b>PROGRAM GUEST LECTURE UNIVERSITAS GAJAYANA MALANG DAN UNIVERSITI TEKNOLOGI MARA MALAYSIA; PERKUAT WAWASAN INTERNASIONAL DOSEN DAN MAHASISWA</b></p>
                    </div>
                </div>
            </div>
        </div>
    </div>




      <!-- Footer -->
  <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                <p>Email:</p>
                <iframe class="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                        width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                        allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="col-md-4">
                <h5>Informasi Tentang</h5>
                <ul>
                    <li><a href="#">Portal Akademik</a></li>
                    <li><a href="#">Calon Mahasiswa</a></li>
                    <li><a href="#">Jadwal Kuliah</a></li>
                    <li><a href="#">Kuliah Online</a></li>
                    <li><a href="#">Journal @UAD</a></li>
                    <li><a href="#">Digital Library</a></li>
                    <li><a href="#">Repository</a></li>
                    <li><a href="#">Conference @UAD</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Link Lainnya</h5>
                <ul>
                    <li><a href="#">Jurnal Pengabdian</a></li>
                    <li><a href="#">Produk Inovasi</a></li>
                    <li><a href="#">Portal UAD</a></li>
                    <li><a href="#">Publikasi Media</a></li>
                    <li><a href="#">Tabloid Digital</a></li>
                    <li><a href="#">Blog UAD</a></li>
                    <li><a href="#">Perpustakaan</a></li>
                    <li><a href="#">Masjid Islamic Center</a></li>
                    <li><a href="#">Asrama Mahasiswa</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.forEach(function (link) {
                    link.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/arsip.blade.php ENDPATH**/ ?>