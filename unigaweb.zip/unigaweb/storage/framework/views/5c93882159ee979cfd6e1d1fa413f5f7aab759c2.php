<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" href="imagef/logo1.png"
    type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   
   <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<body>
    <!-- Jumbotron -->
    <div class="jumbotron" style="background-image: url('<?php echo e(asset('imagef/1.jpg')); ?>');">
    </div>

    <!-- 4 Menu -->
    <div class="menu2">
        <div class="menu-item">
            <div class="icon dashboard-icon"></div>
            <a href="<?php echo e(url('prektor')); ?>" class="nav-link menu-text"><b>PROFIL REKTOR</b></a>
        </div>
        <div class="menu-item">
            <div class="icon cari-alumni-icon"></div>
            <a href="<?php echo e(url('prektor')); ?>" class="nav-link menu-text"><b>PROFIL WAKIL REKTOR</b></a>
        </div>
    </div>

    <!-- White section with rector's welcome -->
    <div class="container-fluid1">
        <img class="rkt" src="<?php echo e(asset('imagef/rektor.jpg')); ?>" alt="2">
        <div class="overlay">
            <h1>Sambutan Rektor</h1>
            <p>
                Assalamu’alaikum wr.wb.<br>
                Kampus merupakan salah satu tempat untuk mengembangkan ilmu oleh mahasiswa, dosen dan peneliti. Hadirnya lembaga penelitian dan pengabdian kepada masyarakat (LPPM) ini menjadi suatu wadah dalam kegiatan penelitian dan pengabdian. Program penelitian dan pengabdian yang dihasilkan nantinya diharapkan mampu menjadi inovasi ilmu pengetahuan, teknologi dan seni (IPTEKS) yang berdaya guna di masyarakat. Kami berharap LPPM Universitas Gajayana Malang dapat berkontribusi di masyarakat melalui program penelitian dan pengabdian yang memanfaatkan potensi alam dan kearifan lokal di daerah Kota Malang. Selain itu, kami juga berterima kasih apabila segenap stakeholder, private partnership dan pemerintah Kota Malang mendukung program penelitian dan pengabdian di UNIGA Malang. Semoga Universitas Gajayana Malang terus maju dan menghasilkan inovasi-inovasi baru. Wassalamu’alaikum wr.wb.<br>
                <h6>Rektor Universitas Gajayana Malang Prof. Dr. Ernani Hadiyati, S.E., M.S.</h6>
            </p>
        </div>
    </div>

    <!-- Horizontal line -->
    <hr>



    <!-- berita -->
    <div class="row">

        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card">
                <img src="imagef/b1.jpg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>Gelar Sosialisasi Rekognisi Pembelajaran Lampau, Uniga Siap Terapkan SIERRA</h4></div>
                    Bertempat di Aula Pascasarjana Gedung C Universitas Gajayana (Uniga) Malang, segenap Pimpinan Universitas, Dekan, Ketua Prodi, dan Calon Asessor mengikuti Sosialisasi Rekognisi Pembelajaran Lampau (RPL)..........
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(url('berita1')); ?>" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card">
                <img src="imagef/b2.jpeg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>Dies Natalis ke-44 Universitas Gajayana Malang; Tingkatkan Inovasi Teknologi, Komitmen Lahirkan Lulusan Adaptif</h4></div>
                    Universitas Gajayana Malang (Uniga) telah mencapai usia ke-44 tahun. Dies Natalisnya dirayakan, Senin (20/5) kemarin. Di hadapan civitas akademika, Rektor Uniga.....
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(url('berita2')); ?>" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6 mb-3">
            <div class="card">
                <img src="imagef/b3.jpg" class="card-img-top" alt="...">

                <div class="card-body">
                    <div class="card-title"><h4>UPACARA PERINGATAN HARI KEBANGKITAN NASIONAL BERSAMAAN DENGAN DIES NATALIS KE-44 UNIGA</h4></div>
                    SIARINDOMEDIA.COM – Bertepatan dengan Hari Kebangkitan Nasional pada 20 Mei, Universitas Gajayana (Uniga) Malang menggelar upacara sekaligus tasyakura...
                </div>

                <div class="card-footer">
                    <a href="<?php echo e(url('berita3')); ?>" class="card-link">Lihat</a>
                </div>
            </div>
        </div>

    </div>


    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                    <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                    <p>Email:</p>
                    <iframe class="map"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                            width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                            allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
                <div class="col-md-4">
                    <h5>Informasi Tentang</h5>
                    <ul>
                        <li><a href="#">Portal Akademik</a></li>
                        <li><a href="#">Jadwal Kuliah</a></li>
                        <li><a href="#">Kuliah Online</a></li>
                        <li><a href="#">Journal @UNIGA</a></li>
                        <li><a href="#">Conference @UNIGA</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Link Lainnya</h5>
                    <ul>
                        <li><a href="#">Jurnal Pengabdian</a></li>
                        <li><a href="#">Blog UNIGA</a></li>
                        <li><a href="#">Perpustakaan</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var navLinks = document.querySelectorAll('.nav-link');

            navLinks.forEach(function (link) {
                link.addEventListener('click', function () {
                    navLinks.forEach(function (link) {
                        link.classList.remove('active');
                    });
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/index.blade.php ENDPATH**/ ?>