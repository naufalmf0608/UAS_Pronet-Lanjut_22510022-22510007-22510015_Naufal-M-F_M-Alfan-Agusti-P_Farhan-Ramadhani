<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" href="imagef/logo1.png"
    type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   
   <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('include.beritas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>


    <!-- Jumbotron -->
    <div class="jumbotron" style="background-image: url('<?php echo e(asset('imagef/1.jpg')); ?>');">
    </div>

    <hr>

    
    <div class="berita">
        <h1>Gelar Sosialisasi Rekognisi Pembelajaran Lampau, Uniga Siap Terapkan SIERRA</h1>

        <p>Bertempat di Aula Pascasarjana Gedung C Universitas Gajayana (Uniga) Malang, segenap Pimpinan Universitas, Dekan, Ketua Prodi, dan Calon Asessor mengikuti Sosialisasi
            Rekognisi Pembelajaran Lampau (RPL). Kegiatan ini diadakan untuk
            meningkatkan kualitas dan entitas calon mahasiswa yang ingin menempuh pendidikan lanjutan di
            Uniga dengan efektifitas masa perkuliahan.</p>

        <p>Selain sebagai kebutuhan penyelenggaraan Perguruan Tinggi Swasta, sosialisasi RPL ini merujuk pada Peraturan Menteri Pendidikan, Kebudayaan, Riset dan Teknologi RI Nomor
            41 tahun 2021 tentang Rekognisi Pembelajaran Lampau, dan Peraturan, serta Peraturan Direktur Jendral Pendidikan Tinggi, Riset, dan Teknologi nomor 162/E/KPT/2022 Tahun 2022
            Tentang Petunjuk Teknis Penyelenggaraan Lampau Pada
            Perguruan Tinggi yang Menyelenggarakan Pendidikan Akademis.</p>

            <img src="<?php echo e(asset('imagef/b1.jpg')); ?>" alt="">

        <p>Bertindak sebagai pemateri dalam sosialisasi kali ini adalah Dr. Drs. Amirul Mustafa., M.Si. (Wakil Rektor 1 Universitas Dr. Soetomo). Pengelola RPL di lingkup Universitas
            Dr. Soetomo ini menyampaikan esensii terkait Sistem E-Rekomendasi Rekognisi Pembelajaran Lampau Akademik
            (SIERRA)</p>
        <p>“Kita mencoba belajar dari Universitas Dr.Soetomo yang sudah mengiplementasikan RPL selama 1,5 tahun, bagaimana gambaran menyeluruh prakteknya di lapamgan, terutama 2 bagian utama yang berkaitan dengan pengorganisasian, peraturan, dan termasuk
            bagaimana teknis operasional SIERRA” Ujar Wakil Rektor 1
            bidang Bidang Akademik dan Umum, Drs.Gunadi, M.Sc., Ph.D.</p>

            <img src="<?php echo e(asset('imagef/berita1bag2.jpg')); ?>" alt="">

        <p>Lebih jauh Dr. Amirul Mustafa dalam paparannya menekankan pentingnya kerjasama antar Fakultas dan Universitas. Rekognisi Pembelajaran Lampau menjadi jalan keluar yang ditempuh dalam mewadahi calon
            mahasiswa yang sudah bekerja untuk melanjutkan pendidikannya melalui
            konversi Sistem Kredit Semester (SKS). (key)</p>

    </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                <p>Email:</p>
                <iframe class="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                        width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                        allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="col-md-4">
                <h5>Informasi Tentang</h5>
                <ul>
                    <li><a href="#">Portal Akademik</a></li>
                    <li><a href="#">Calon Mahasiswa</a></li>
                    <li><a href="#">Jadwal Kuliah</a></li>
                    <li><a href="#">Kuliah Online</a></li>
                    <li><a href="#">Journal @UAD</a></li>
                    <li><a href="#">Digital Library</a></li>
                    <li><a href="#">Repository</a></li>
                    <li><a href="#">Conference @UAD</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Link Lainnya</h5>
                <ul>
                    <li><a href="#">Jurnal Pengabdian</a></li>
                    <li><a href="#">Produk Inovasi</a></li>
                    <li><a href="#">Portal UAD</a></li>
                    <li><a href="#">Publikasi Media</a></li>
                    <li><a href="#">Tabloid Digital</a></li>
                    <li><a href="#">Blog UAD</a></li>
                    <li><a href="#">Perpustakaan</a></li>
                    <li><a href="#">Masjid Islamic Center</a></li>
                    <li><a href="#">Asrama Mahasiswa</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.forEach(function (link) {
                    link.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/berita1.blade.php ENDPATH**/ ?>