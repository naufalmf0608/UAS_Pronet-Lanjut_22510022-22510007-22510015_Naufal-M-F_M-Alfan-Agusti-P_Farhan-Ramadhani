<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" href="imagef/logo1.png" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.beritas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>


    <!-- Jumbotron -->
    <div class="jumbotron" style="background-image: url('<?php echo e(asset('imagef/1.jpg')); ?>');">
    </div>

    <hr>

    
    <div class="berita">
        <img src="<?php echo e(asset('imagef/b2.jpeg')); ?>" alt="">
        <h1>Gelar Sosialisasi Rekognisi Pembelajaran Lampau, Uniga Siap Terapkan SIERRA</h1>

        <p>MALANG POSCO MEDIA, MALANG– Universitas Gajayana Malang (Uniga) telah mencapai usia ke-44 tahun. Dies Natalisnya dirayakan, Senin (20/5) kemarin. Di hadapan civitas akademika, Rektor Uniga Prof. Dr. Ernani Hadiyati, S.E., M.S bersuara dengan lantang.</p>

        <p>Dia ingin momentum Dies Natalis ke-44 ini menjadi ajang untuk membakar semangat dosen, tenaga kependidikan dan mahasiswa. Prof Ernani mengingatkan, bahwa kemajuan teknologi informasi berkembang begitu cepat. Demikian juga tantangan dan kompetisinya. “Maka jangan ada lagi yang apatis terhadap kondisi ini. Semua harus mampu mengembangkan diri, sesuai bidang dan kompetensinya. Kalau tidak kita akan tertinggal,” ucapnya.</p>

        <img src="<?php echo e(asset('imagef/b2p1.jpeg')); ?>" alt="">

        <p>Dia menegaskan, bahwa seiring dengan kemajuan teknologi, Uniga juga bertransformasi untuk terus berinovasi menyelenggarakan Tri Dharma Perguruan Tinggi secara optimal. Mengembangkan model pembelajaran inovatif, berbasis riset, dan meningkatkan produktivitas karya ilmiah, guna memberikan kontribusinya terhadap pembangunan bangsa.</p>

        <p>“Kami berkomitmen untuk meningkatkan inovasi dalam pengajaran berbasis teknologi informasi disertai pengintegrasian pendidikan dan memperkuat basis hard skill dan soft skill agar dapat menghasilkan lulusan yang adaptif dengan dunia usaha dan dunia kerja,” terangnya.</p>

        <p>Prof Ernani mengungkapkan, bahwa di usia ke-44 tahun Uniga telah meraih energi kemajuan dalam bidang Tri Dharma Perguruan Tinggi. Begitu juga dengan alumni. Mereka telah menunjukkan sumbangsihnya terhadap bangsa dan negara melalui kiprah mereka di berbagai lembaga dan organisasi. “Ini semua memperlihatkan bahwa Uniga telah berkontribusi terhadap kemajuan bangsa dan negara,” ungkapnya.</p>
        <img src="<?php echo e(asset('imagef/b2p2.jpeg')); ?>" alt="">

        <p>Saat ini Uniga telah berada pada pencapaian perguruan tinggi yang berproses secara optimal, guna melahirkan lulusan yang dapat mengimplementasikan ilmunya dalam lingkup entitas masyarakat. Dimanapun mereka berada. Sehingga keberadaan alumni Uniga memberikan kontribusi positif terhadap lingkungan masyarakatnya.</p>

       <p>Prof Ernani menjelaskan, untuk meningkatkan nilai akreditasi, perlu upaya yang strategis. Antara lain, menjalin kerjasama dengan beberapa universitas luar negeri. Salah satunya Universiti Teknologi Malaysia (UTM). “Dengan UTM kami sudah bekerjasama dengan sangat baik. Beberapa program telah terlaksana. Seperti guest lecture dan sebagainya, termasuk kami akan melaksanakan student exchange,” kata dia.
    </p>

    <p>Menurutnya, Perguruan Tinggi Swasta menghadapi tantangan yang kian tidak mudah. Antara lain akreditasi dan penjaminan mutu, kualitas SDM, jumlah mahasiswa, variasi kuliah dan fasilitas pendidikan, sumber dana yang tidak pasti, kompetisi ketat, kesesuaian kurikulum dengan tuntutan industri dan sebagainya.
    </p>
    <img src="<?php echo e(asset('imagef/b2p3.jpg')); ?>" alt="">
    <p>
        “Kekuatan utama untuk menghadapi tantangan tersebut adalah SDM. Maka para dosen tidak boleh apatis melihat tantangan tersebut. Harus ada upaya untuk pengembangan diri secara komprehensif dan sinergitas dengan stakeholder diperkuat,” tambahnya.
    </p>

    <p>
        Rektor Uniga mengimbau seluruh civitas akademika untuk memperkuat sinergi demi eksistensi Uniga yang lebih baik. Serta meningkatkan optimisme, kreativitas, dan produktivitas. “Mari kita bersinergi untuk memperkuat eksistensi Uniga melalui kontribusi optimal di bidang masing-masing. Dan menjaga solidaritas demi kemajuan Uniga,” pungkasnya. (imm/adv/udi)
    </p>

    Sebagai rektor, Prof Ernani tidak akan berhenti mendorong dan memfasilitasi prodi untuk meningkatkan akreditasinya. Utamanya yang masih berada di peringkat baik. “Upaya revitalisasi kelembagaan perlu terus dilakukan. Agar Uniga sebagai institusi perguruan tinggi, tidak hanya sekedar eksis tapi mampu berkembang dan mengakselerasikan dengan dinamika internal maupun eksternal,” tuturnya.
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                    <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                    <p>Email:</p>
                    <iframe class="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                        width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" frameborder="0" allowfullscreen=""
                        aria-hidden="false" tabindex="0"></iframe>
                </div>
                <div class="col-md-4">
                    <h5>Informasi Tentang</h5>
                    <ul>
                        <li><a href="#">Portal Akademik</a></li>
                        <li><a href="#">Calon Mahasiswa</a></li>
                        <li><a href="#">Jadwal Kuliah</a></li>
                        <li><a href="#">Kuliah Online</a></li>
                        <li><a href="#">Journal @UAD</a></li>
                        <li><a href="#">Digital Library</a></li>
                        <li><a href="#">Repository</a></li>
                        <li><a href="#">Conference @UAD</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Link Lainnya</h5>
                    <ul>
                        <li><a href="#">Jurnal Pengabdian</a></li>
                        <li><a href="#">Produk Inovasi</a></li>
                        <li><a href="#">Portal UAD</a></li>
                        <li><a href="#">Publikasi Media</a></li>
                        <li><a href="#">Tabloid Digital</a></li>
                        <li><a href="#">Blog UAD</a></li>
                        <li><a href="#">Perpustakaan</a></li>
                        <li><a href="#">Masjid Islamic Center</a></li>
                        <li><a href="#">Asrama Mahasiswa</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                navLinks.forEach(function(link) {
                    link.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/berita2.blade.php ENDPATH**/ ?>