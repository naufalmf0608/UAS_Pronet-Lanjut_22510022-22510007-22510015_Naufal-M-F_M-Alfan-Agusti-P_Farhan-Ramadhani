<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/include/style.blade.php ENDPATH**/ ?>