<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Jurnal</title>
    <link rel="icon" href="imagef/logo1.png" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/crudjurnal.css')); ?>">

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('imagef/logo.png')); ?>" alt="Logo" width="300" height="auto">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto" id="navbar-menu">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(url('index')); ?>"><b>Home</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('lppm')); ?>"><b>Tentang LPPM</b></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="jurnalDropdown" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b>Jurnal</b></a>
                    <div class="dropdown-menu" aria-labelledby="jurnalDropdown">
                        <a class="dropdown-item" href="/baca">Baca Jurnal</a>
                        <a class="dropdown-item active" href="<?php echo e(url('crudjurnal')); ?>">Input Jurnal</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('arsip')); ?>"><b>Arsip</b></a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="forminput">
        <div class="row">
            <div class="col-md-6">
                <h2>Form Input Data</h2>

                <!-- Menampilkan pesan error jika validasi gagal -->
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Menampilkan pesan sukses jika jurnal berhasil diupload -->
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('store-jurnal')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama:</label>
                        <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama" required>
                    </div>
                    <div class="form-group">
                        <label for="nim">NIM/NIDN:</label>
                        <input type="text" class="form-control" id="nim" name="nim" placeholder="Masukkan NIM" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required>
                    </div>
                    <div class="form-group">
                        <label for="file">Upload PDF Jurnal (Maks. 10 MB):</label>
                        <input type="file" class="form-control-file" id="file" name="file" accept=".pdf" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>LEMBAGA PENELITIAN DAN PENGABDIAN KEPADA MASYARAKAT</h5>
                    <p>Jl. Mertojoyo Blk. L, Merjosari, Kec. Lowokwaru, Kota Malang, Jawa Timur 65144</p>
                    <p>Email:</p>
                    <iframe class="map"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.563204660936!2d112.59996737390449!3d-7.940602379089298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd6281bf5024dbb%3A0x7c59f80869f3bbea!2sUniversitas%20Gajayana!5e0!3m2!1sid!2sid!4v1717718806382!5m2!1sid!2sid"
                            width="600" height="450" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade" frameborder="0"
                            allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
                <div class="col-md-4">
                    <h5>Informasi Tentang</h5>
                    <ul>
                        <li><a href="#">Portal Akademik</a></li>
                        <li><a href="#">Calon Mahasiswa</a></li>
                        <li><a href="#">Jadwal Kuliah</a></li>
                        <li><a href="#">Kuliah Online</a></li>
                        <li><a href="#">Journal @UAD</a></li>
                        <li><a href="#">Digital Library</a></li>
                        <li><a href="#">Repository</a></li>
                        <li><a href="#">Conference @UAD</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Link Lainnya</h5>
                    <ul>
                        <li><a href="#">Jurnal Pengabdian</a></li>
                        <li><a href="#">Produk Inovasi</a></li>
                        <li><a href="#">Portal UAD</a></li>
                        <li><a href="#">Publikasi Media</a></li>
                        <li><a href="#">Tabloid Digital</a></li>
                        <li><a href="#">Blog UAD</a></li>
                        <li><a href="#">Perpustakaan</a></li>
                        <li><a href="#">Masjid Islamic Center</a></li>
                        <li><a href="#">Asrama Mahasiswa</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var navLinks = document.querySelectorAll('.nav-link');

            navLinks.forEach(function (link) {
                link.addEventListener('click', function () {
                    navLinks.forEach(function (link) {
                        link.classList.remove('active');
                    });
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\unigaweb\unigaweb\resources\views/crudjurnal.blade.php ENDPATH**/ ?>